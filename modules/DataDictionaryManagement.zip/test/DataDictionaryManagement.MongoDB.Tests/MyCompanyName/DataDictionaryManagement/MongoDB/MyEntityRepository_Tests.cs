﻿namespace DataDictionaryManagement.MongoDB
{
    public class MyEntityRepository_Tests : MyEntityRepository_Tests<DataDictionaryManagementMongoDbTestModule>
    {

    }
}
