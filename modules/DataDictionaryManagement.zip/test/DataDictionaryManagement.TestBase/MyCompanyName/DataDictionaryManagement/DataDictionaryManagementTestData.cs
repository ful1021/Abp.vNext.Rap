﻿using Volo.Abp.DependencyInjection;

namespace DataDictionaryManagement
{
    public class DataDictionaryManagementTestData : ISingletonDependency
    {
    }
}
