﻿namespace DataDictionaryManagement
{
    public abstract class DataDictionaryManagementDomainTestBase : DataDictionaryManagementTestBase<DataDictionaryManagementDomainTestModule>
    {

    }
}