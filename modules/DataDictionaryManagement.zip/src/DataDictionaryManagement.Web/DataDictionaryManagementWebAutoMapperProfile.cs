﻿using AutoMapper;

namespace DataDictionaryManagement
{
    public class DataDictionaryManagementWebAutoMapperProfile : Profile
    {
        public DataDictionaryManagementWebAutoMapperProfile()
        {
            //Create mappings.
        }
    }
}