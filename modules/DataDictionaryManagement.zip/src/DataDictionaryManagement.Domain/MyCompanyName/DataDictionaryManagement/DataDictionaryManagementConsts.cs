﻿namespace DataDictionaryManagement
{
    public static class DataDictionaryManagementConsts
    {
        public const string DefaultDbTablePrefix = "DataDictionaryManagement";

        public const string DefaultDbSchema = null;
    }
}
