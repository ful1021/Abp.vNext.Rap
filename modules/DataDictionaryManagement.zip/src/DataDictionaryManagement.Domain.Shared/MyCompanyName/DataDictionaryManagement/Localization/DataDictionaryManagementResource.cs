﻿using Volo.Abp.Localization;

namespace DataDictionaryManagement.Localization
{
    [LocalizationResourceName("DataDictionaryManagement")]
    public class DataDictionaryManagementResource
    {
        
    }
}
