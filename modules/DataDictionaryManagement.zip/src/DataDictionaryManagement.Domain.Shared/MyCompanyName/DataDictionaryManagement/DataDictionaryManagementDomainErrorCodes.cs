﻿namespace DataDictionaryManagement
{
    public static class DataDictionaryManagementDomainErrorCodes
    {
        //Add your business exception error codes here...
    }
}
