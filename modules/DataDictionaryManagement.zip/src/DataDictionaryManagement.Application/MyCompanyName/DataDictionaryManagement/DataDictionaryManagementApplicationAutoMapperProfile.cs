﻿using AutoMapper;

namespace DataDictionaryManagement
{
    public class DataDictionaryManagementApplicationAutoMapperProfile : Profile
    {
        public DataDictionaryManagementApplicationAutoMapperProfile()
        {
            
        }
    }
}